#include <iostream>
using namespace std;
int main() {
    cout << "printed s h uccesfully k";
    return 0;
}
