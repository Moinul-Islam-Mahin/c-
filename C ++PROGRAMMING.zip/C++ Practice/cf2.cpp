#include <iostream>
using namespace std;
int main()
{
    string str1,str2;
    cin>>str1>>str2;
    cout<<str1<<" "<<str2;
    return 0;




}
