#include<iostream>
using namespace std;
int swap(int *num1 , int *num2);
int num1, num2;

int swap(int *num1, int *num2)
{
    int temp;
    temp = *num1;
    *num1= *num2;
    *num2= temp;
}
int main()
{ cout<<"enter your first number"<<endl;
cin>>num1;
cout<<"enter your second number"<<endl;
cin>>num2;
swap(&num1, &num2);
    cout<<"after swapped first number is "<<num1<<" & second number is "<<num2;
   return 0;
}
