#include<iostream>
using namespace std ;
void square()
{
 float length,area;
 cout<<"enter your length of square"<<endl;
 cin>>length;
 cout<<"area of your square shape is = "<<length*length<<endl;
}
void rectengle()
{  float length,width;
    cout<<"enter your length and width "<<endl;
    cin>>length>>width;
    cout<<"the area of your rectangle shape is ="<<length*width<<endl;
}
void circle()
{ float radius;
    cout<<"enter your radius of your circle"<<endl;
    cin>>radius;
    cout<<"the area of your circle is ="<<3.1416*radius*radius<<endl;
}
void triangle()
{
    float base,height;
    cout<<"enter base & height of your triangle"<<endl;
    cin>>base>>height;
    cout<<"the area of your triangle is ="<<0.5*base*height<<endl;
}

int main()
{
    int choice , lenggth , height,width;

    cout<<"select your shape from"<<endl;
    cout<<"1. Square"<<endl ;
    cout<<"2. Circle"<<endl ;
    cout<<"3. Rectangle "<<endl;
    cout<<"4. Triangle "<<endl;
    cout<<" select Your option : " ;
    cin>>choice ;
    switch(choice)
    {
    case 1:
        square() ;
        break ;
    case 2:
        rectengle();
        break ;
    case 3:
        circle();
        break;
        case 4:
        triangle();
        break;
    default :
        cout<<"Invalid option"<<endl ;
        break;
  }
return 0 ;
}
