#include<iostream>
using namespace std;
int main(void)
{
    int number,remainder,first;
    cout<<"input a number of four digits" <<endl;
    cin>>number;
    int last_digit;
    int middle_digit;
    last_digit=number%10;
    middle_digit= number%100;
    first= number/1000;

    cout<<" last digit is = "<<last_digit<<endl;
    cout<< "middle digit is= "<<middle_digit<<endl;
cout<<"first digit"<<first<<endl;

    return 0;

}
