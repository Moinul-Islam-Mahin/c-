#include <iostream>
using namespace std;

class Teacher {
private:
    int teacherID;
    string teacherName;
    double salary;

public:
    // Parameterized constructor
    Teacher(int id, string name, double sal)
        : teacherID(id), teacherName(name), salary(sal) {}

    // Setter methods
    void setTeacherID(int id) { teacherID = id; }
    void setTeacherName(string name) { teacherName = name; }
    void setSalary(double sal) { salary = sal; }

    // Getter methods
    int getTeacherID() const { return teacherID; }
    string getTeacherName() const { return teacherName; }
    double getSalary() const { return salary; }

    // Method to display teacher details
    void display() const {
        cout << "Teacher ID: " << teacherID << "\n"
             << "Teacher Name: " << teacherName << "\n"
             << "Monthly Salary: $" << salary << "\n";
    }

    // Method to display yearly salary
    void yearlySalary() const {
        cout << "Yearly Salary: $" << (salary * 12) << "\n";
    }
};

int main() {
    // Creating first teacher using the parameterized constructor
    Teacher t1(101, "Hasibul Hasan", 4500.0);
    t1.display();
    t1.yearlySalary();

    // Creating second teacher using the parameterized constructor
    cout << "\nCreating t2 using parameterized constructor...\n";
    Teacher t2(102, "Bob Smith", 5000.0);
    t2.display();
    t2.yearlySalary();

    return 0;
}
