#include<iostream>
#include <cmath>
using namespace std;
struct Triangle
{
  double side1;
  double side2;
  double side3;
  int triangleType()
{
    if (side1 == side2 && side2 == side3)
    {
      return 1;
    }
    else if (side1 == side2 || side1 == side3 || side2 == side3)
    {
      return 2;
    }
    else
    {
      return 3;
    }

  }
    double findArea()
  {
    double s = (side1 + side2 + side3) / 2;
   return sqrt(s * (s - side1) * (s - side2) * (s - side3));
  }
};

int main()
{
  Triangle triangle1;
  triangle1.side1 = 4;
  triangle1.side2 = 3;
  triangle1.side3 = 3;
  Triangle triangle2;
  triangle2.side1 = 5;
  triangle2.side2 = 4;
  triangle2.side3 = 5;
cout << "Triangle 1 Area: " << triangle1.findArea() << endl;
cout << "Triangle 2 Area: " << triangle2.findArea() << endl;
if ( triangle1.findArea() > triangle2.findArea() )
  {
    cout << "Triangle 1 has bigger area. " << endl;
  }
 else if ( triangle1.findArea() < triangle2.findArea() )
  {
    cout << "Triangle 2 has bigger area. " << endl;
  }
 else
  {
    cout << "Both triangles have the same area. " << endl;
  }
  if(triangle1.triangleType()==1)
  {
      cout<<"Triangle 1 is Equilateral"<<endl;
  }
  else if(triangle1.triangleType()==2)
  {
    cout<<"Triangle 1 is Isosceles"<<endl;
  }
  else if (triangle1.triangleType()==3)
  {
    cout<<"Triangle 1 is Scalene"<<endl;
  }

  if(triangle2.triangleType()==1)
  {
      cout<<"Triangle 2 is Equilateral"<<endl;
  }
  else if(triangle2.triangleType()==2)
  {
    cout<<"Triangle 2 is Isosceles"<<endl;
  }
  else if (triangle2.triangleType()==3)
  {
    cout<<"Triangle 2 is Scalene"<<endl;
  }

if ( triangle1.triangleType() == triangle2.triangleType() )
  {
    cout << "Both triangles are the same type. " << endl;
  }
else
  {
    cout << "Triangles are different types. " << endl;
  }
return 0;
}




