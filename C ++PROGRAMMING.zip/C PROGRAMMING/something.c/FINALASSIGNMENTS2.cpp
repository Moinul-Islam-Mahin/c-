#include <iostream>
#include <string>

using namespace std;

// Define a struct for Teacher
struct Teacher {
    int teacherID;
    string teacherName;
    double salary;

    // Method to set teacher details
    void setDetails(int id, string name, double sal) {
        teacherID = id;
        teacherName = name;
        salary = sal;
    }

    // Method to get teacher ID
    int getTeacherID() {
        return teacherID;
    }

    // Method to get teacher name
    string getTeacherName() {
        return teacherName;
    }

    // Method to get teacher salary
    double getSalary() {
        return salary;
    }

    // Method to display teacher details
    void displayDetails() {
        cout << "\nTeacher Details:\n";
        cout << "ID: " << teacherID << endl;
        cout << "Name: " << teacherName << endl;
        cout << "Salary: $" << salary << endl;
    }

    // Method to calculate and display yearly salary
    void yearlySalary() {
        double yearly = salary * 12;
        cout << "Yearly Salary: $" << yearly << endl;
    }
};

int main() {
    // Create an instance of Teacher
    Teacher t1;

    // Set teacher details
    t1.setDetails(101, "John Doe", 5000);

    // Display teacher details
    t1.displayDetails();

    // Display yearly salary
    t1.yearlySalary();

    return 0;
}
