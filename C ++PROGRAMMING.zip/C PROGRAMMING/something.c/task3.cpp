#include<iostream>
using namespace std;
int main()
{
   int a,b,c;
   cout<<"enter your three numbers "<<endl;
   cin>>a>>b>>c;
   if(a>b && a>c)
   {

   cout<<"largest "<<a<<endl;
   }

   else if(b>c && b>c)
    {cout<<"largest "<<b<<endl;}
   else
    {cout<<" largest"<<c;}
return 0; }
