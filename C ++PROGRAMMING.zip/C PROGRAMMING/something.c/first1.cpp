#include <iostream>
using namespace std;
int rowSum = 0; // Global variable to store the sum of row 0
void computeRowSum(int matrix[4][4], int row) {
    for (int j = 0; j < 4; ++j) {
        rowSum += matrix[row][j]; // Add elements of the specified row
        cout << matrix[row][j] << " "; // Print elements of the row
    \
    cout << endl; // Line break after printing the row
}}
int computeMainDiagonalSum(int matrix[4][4]) {
    int diagSum = 0;
    for (int i = 0; i < 4; ++i) {
        cout << matrix[i][i] << endl; // Print diagonal elements
        diagSum += matrix[i][i]; // Add diagonal elements
    }
    return diagSum;
}

int main() {
    int matrix[4][4] = {
        {3, 2, 7, 4},
        {6, 1, 9, 5},
        {8, 3, 5, 2},
        {4, 6, 1, 8}
    };
   cout << "Elements of row 0: ";
    computeRowSum(matrix, 0); // Process row 0
    cout << "Sum of row 0: " << rowSum << endl;

    cout << "Main diagonal elements:" << endl;
    int diagSum = computeMainDiagonalSum(matrix); // Process main diagonal
    cout << "Sum of diagonal elements: " << diagSum << endl;

    cout << "Final Result (Row Sum + Diagonal Sum): " << rowSum + diagSum << endl;

    return 0;
}


