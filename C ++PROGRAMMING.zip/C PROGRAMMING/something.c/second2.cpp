#include<iostream>
using namespace std;
int main(void)
{ int number;
cout<<"enter a value of a" <<endl;
cin>>a ;
cout<<"enter value of b"<<endl;
cin>>b;
cout<<"enter value of c"<<endl;
cin>>c;
switch(number)
{
case 'a>b' :
    cout<< "a is the greatest"<<;
    break ;
    case 'b>c' :
    cout<<"maybe";
    break;
    case 'z':
cout<<"zoo";
break;

    default:
        cout<< "invalid response";

}
return 0;

}
