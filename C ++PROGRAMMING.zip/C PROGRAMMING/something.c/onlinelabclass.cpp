#include<iostream>
using namespace std;
int fun( int c)
{ int remainder,reversed_number=0;
  while(c!=0)
  {
   remainder=c%10;
   reversed_number= reversed_number*10+remainder;
  c=c/10;
  }
  cout<<"reversed number is = "<<reversed_number<<endl;
}
int main()
{ int number;

   for(int i=1;i!=0; i++)
       {
       cout<<"enter your number to reversed"<<endl;
       cin>>number;
       if(number==0){break;}
       fun(number);
       }
    return 0;
}
