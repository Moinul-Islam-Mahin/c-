#include<iostream>
using namespace std;
//int rows,cols;

int main(){
    int rows,cols;
    cin>>rows>>cols;
int** matrix= new int*[rows];
for(int i=0; i<rows; i++)
{
    matrix[i]= new int[cols];
}
for(int i=0; i<rows; i++)
{
    for(int j=0; i<cols; j++)
    {
        cin>>matrix[i][j];
    }
}
for(int i=0; i<rows; i++)
{
    for(int j=0; i<cols; j++)
    {
        cin>>matrix[i][j];
    }
    cout<<endl;
}
for(int i=0;i<rows;i++)
{
    delete [] matrix[i];
}

delete matrix;
return 0;}
