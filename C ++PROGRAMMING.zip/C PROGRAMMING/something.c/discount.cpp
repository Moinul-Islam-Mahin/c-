#include<iostream>
using namespace std;
int main(void)
{
    float p= 52.25,q,T,T2;
    cout<<"enter quantity"<<endl;
    cin>>q;
    T = p*q;
    if(T>500)

       {

        T2 = (T-((10/100)*T));
    cout<<"discount price: "<<T2<<endl;
       }

    else
        cout<<"discount does not availed";
        return 0;
}
