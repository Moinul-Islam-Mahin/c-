#include <iostream>
using namespace std;
int main() {
int arr[3][2];
cout << "Enter 6 integer values for the 3x2 array:" << endl;
   for (int i = 0; i < 3; i++) {
   for (int j = 0; j < 2; j++) {
           cin >> arr[i][j];
       }
   }
cout << "Even values:" << endl;
   for (int i = 0; i < 3; i++) {
   for (int j = 0; j < 2; j++) {
   if (arr[i][j] % 2 == 0) {
cout << arr[i][j] << " ";
           }
       }
   }
   cout << endl;
   cout << "Odd values:" << endl;
   for (int i = 0; i < 3; i++) {
   for (int j = 0; j < 2; j++) {
   if (arr[i][j] % 2 != 0) {
   cout << arr[i][j] << " ";
           }
       }
   }
   cout << endl;
   return 0;
}
