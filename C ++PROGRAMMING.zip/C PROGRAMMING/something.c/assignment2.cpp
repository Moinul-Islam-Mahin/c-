/* Write a cpp code to find out first 5 febonacci series number */
#include<iostream>
using namespace std;
int main ()
{ int fibonacci[5];
fibonacci[0]=0;
fibonacci[1]=1;
for(int x=2; x<5; x++)
{
fibonacci[x]=fibonacci[x-2]+fibonacci[x-1];
}
cout<<"first 5 febonacci series numbers are : "<<endl;
for(int y=0; y<5 ; y++)
{
    cout<<fibonacci[y]<<endl;
}
return 0;
}
