#include<iostream>
using namespace std;
int main()
{
    int price=70;
    int amount;
    int total = 0;
    cout<<"number of cupcake uses wanna buy "<<endl;
    cin>>amount;
    if(amount>=2)
        cout<<"You get a free cupcake"<<endl;
    else
        cout<<"you are missing out a great deal"<<endl;
    total= amount*price;
    if(total>=700)
    {
        float discountprice;
        discountprice = total-(total*0.08);
        cout<<"price after discount is = "<<discountprice<<endl;
    }
    else
        cout<<"your total bill is = "<<total;


    return 0;
}
