#include<stdio.h>
void main()
 {
    printf( "Heello myself MOinul Islam. \n I'm currently studying Bsc(hons) CSE in AIUB. \n I have finshed my HSC with gpa5 from Gurudoyal Govt. College,Kishoreganj. \n And I have finished my SSC  with gpa5 from Kishoreganj Govt Boys High School, Kishoreganj . ");
    printf( " \n welcome to  c programming class everyone.");
    getch();
 }
