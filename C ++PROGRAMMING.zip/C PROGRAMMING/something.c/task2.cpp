#include<iostream>
using namespace std;
int main()
{
    char ch;

cout<<"input your character"<<endl;
cin>>ch;

if(ch== 'a' || ch=='A')
{
    cout<<"the character is vowel";

}
else if(ch== '0' || ch=='O')
{
    cout<<"the character is vowel";

}
else if(ch== 'I' || ch== 'i')
{
    cout<<"the character is vowel";

}
else if(ch== 'u' || ch== 'U')
{
    cout<<"the character is vowel";
}
else if(ch== 'e' || ch=='E')
{
    cout<<"the character is vowel";

}
else
{

 cout<<"the character is consonant";}







return 0;
}
