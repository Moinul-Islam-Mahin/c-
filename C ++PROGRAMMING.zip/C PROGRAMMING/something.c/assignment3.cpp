/* Write a cpp code to print the following using a loop:
	*
	***
	*****
	*******
 */
#include<iostream>
using namespace std;
int main()
{ int i;
for(i=1; i<9; i=i+2)
{
    for(int j=0;j<i; j++)
    {
        cout<<"*";
    }
    cout<<endl;
}
return 0;
}
