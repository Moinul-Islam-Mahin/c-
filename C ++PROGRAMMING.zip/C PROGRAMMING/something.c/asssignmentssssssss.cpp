/* Declare an array with the characters of your name, all should be capitals [example:= char name[] =  {�S�, �H�, �A�, �R�, �M�, �E�, �E�, �N�, �.�}; ].
Then take a character as input and find out if that character is present in your name array. Continue taking inputs and comparing as long as the input is not �.� (hint: perform array & for loop inside a while loop).
  */

#include<iostream>
#include<conio.h>
using namespace std;
int main()
{ char anything;

   char name[]={"SHARMEEN."};
    cout<<"enter your character to check"<<endl;
    cin>>anything;
    strchr{ name[],anything};










    return 0;
}

