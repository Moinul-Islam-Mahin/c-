#include<iostream>
using namespace std;
int main() {
cout<< " hello world \n how are you all? " <<endl ;
return 0;




}
