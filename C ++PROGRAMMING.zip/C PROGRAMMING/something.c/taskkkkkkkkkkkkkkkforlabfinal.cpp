#include <iostream>
using namespace std;
int main() {
int arr[2][3];
cout << "Enter 6 integer values for the 2x3 array:" << endl;
   for (int i = 0; i < 2; i++) {
   for (int j = 0; j < 3; j++) {
           cin >> arr[i][j];
       }
   }
   int arry[2][3];

   for (int i = 0; i < 3; i++) {
   for (int j = 0; j < 2; j++) {
   if (arr[i][j] <0)
    {
      arry[i][j]=arr[i][j];
      cout<<arry[i][j]<<"  ";

           }
       }
   }

   for (int i = 0; i < 2; i++) {
   for (int j = 0; j < 3; j++) {
   if (arr[i][j] >0) {
   arry[i][j]=arr[i][j] ;
   cout<<arry[i][j]<<"  ";
           }
       }
   }
   cout << endl;
   return 0;
}

