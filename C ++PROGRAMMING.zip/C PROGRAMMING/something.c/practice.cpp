#include <iostream>
using namespace std;

int main() {
    // Define the sizes of the matrices
    const int rowsA = 3, colsA = 2; // Dimensions of Matrix A
    const int rowsB = 2, colsB = 4; // Dimensions of Matrix B

    // Declare matrices
    int A[rowsA][colsA];
    int B[rowsB][colsB];
    int C[rowsA][colsB] = {0}; // Resultant matrix (rowsA x colsB)

    // Input for Matrix A
    cout << "Enter elements of Matrix A (" << rowsA << "x" << colsA << "):" << endl;
    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsA; j++) {
            cin >> A[i][j];
        }
    }

    // Input for Matrix B
    cout << "Enter elements of Matrix B (" << rowsB << "x" << colsB << "):" << endl;
    for (int i = 0; i < rowsB; i++) {
        for (int j = 0; j < colsB; j++) {
            cin >> B[i][j];
        }
    }

    // Matrix Multiplication
    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsB; j++) {
            for (int k = 0; k < colsA; k++) { // Note: colsA == rowsB
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    // Output the resultant matrix
    cout << "Resultant Matrix C (" << rowsA << "x" << colsB << "):" << endl;
    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsB; j++) {
            cout << C[i][j] << " ";
        }
        cout << endl;
    }

    return 0;

}




int** matrix = new int*[rows];
for(int i=0; i<rows; i++)
{
    matrix[i]=new int [cols];
}

for(int i=0; i<rows; i++)
    {
      delete[] matrix[i];

    }
delete [] matrix;
