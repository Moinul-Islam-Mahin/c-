#include<iostream>
using namespace std;
int main()
{
    int number;
cout<<"input your number"<<endl;
cin>>number;
if(number >= 80)
{
    cout<<"EXCELLENT";

}
else if(number >= 65 && number < 80 )
{
    cout<<"GOOD";

}
else if(number >= 50 && number <65)
{
    cout<<"OKAY";
}
else if(number >= 30 && number < 50)
{
    cout<<"POOR";
}

else if(number <= 30)
{
    cout<<"VERY POOR";
}


return 0;
}
