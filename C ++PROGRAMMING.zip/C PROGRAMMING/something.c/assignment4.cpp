/*  Write a cpp code to find out the summation and average of all the numbers of an array. Array should consist of
10 floating point numbers which will be given as input by user.    */
#include<iostream>
using namespace std;
int main()
{
    float sum=0,avg, numbers[10];
cout<<" Enter your numbers: " <<endl;
for(int x =0; x<10; x++)
{
    cin>>numbers[x];
    sum=sum+numbers[x];
}
avg=sum/10;
cout<<" summation of your entered numbers is = "<<sum<<endl;
cout<<" average of your entered numbers is = "<<avg<<endl;

return 0;
}
