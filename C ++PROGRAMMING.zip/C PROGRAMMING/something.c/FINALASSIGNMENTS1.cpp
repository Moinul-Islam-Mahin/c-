#include <iostream>
#include <iomanip>
using namespace std;
const int BRANCHES = 3;
const int DAYS = 7;
// Function to display the sales data
void displaySales(int sales[BRANCHES][DAYS]) {
    cout << "Sales Data (Branches x Days):\n";
    for (int i = 0; i < BRANCHES; i++) {
        for (int j = 0; j < DAYS; j++) {
            cout << sales[i][j] << " ";
        }
        cout << endl;
    }
}

// Function to calculate the sum of sales for each branch
void calculateSum(int sales[BRANCHES][DAYS]) {
    cout << "\nSum of Sales for Each Branch:\n";
    for (int i = 0; i < BRANCHES; i++) {
        int sum = 0;
        for (int j = 0; j < DAYS; j++) {
            sum += sales[i][j];
        }
        cout << "Branch " << i + 1 << ": " << sum << endl;
    }
}

// Function to calculate the average sales for each branch
void calculateAverage(int sales[BRANCHES][DAYS]) {
    cout << "\nAverage Sales for Each Branch:\n";
    for (int i = 0; i < BRANCHES; i++) {
        int sum = 0;
        for (int j = 0; j < DAYS; j++) {
            sum += sales[i][j];
        }
        double avg = static_cast<double>(sum) / DAYS;
        cout << "Branch " << i + 1 << ": " << fixed << setprecision(2) << avg << endl;
    }
}

int main() {
    int sales[BRANCHES][DAYS] = {
        {1200, 1500, 1100, 1400, 1300, 1600, 1700},
        {1000, 1100, 1200, 1300, 1400, 1500, 1600},
        {900, 1000, 1100, 1200, 1300, 1400, 1500}
    };

    displaySales(sales);
    calculateSum(sales);
    calculateAverage(sales);

    return 0;
}
