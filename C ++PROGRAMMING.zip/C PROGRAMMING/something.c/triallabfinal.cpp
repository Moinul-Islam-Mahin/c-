#include <iostream>
using namespace std;
int main() {
int arr[2][3];
cout << "Enter 6 integer values for the 2x3 array:" << endl;
   for (int i = 0; i < 2; i++) {
   for (int j = 0; j < 3; j++) {
           cin >> arr[i][j];
       }
   }
   //int a=0,b=0;
   int arry[2][3];
 for (int i = 0,int x=0; x<3, i < 3;x++, i++) {
   for (int j = 0,int y=0; j < 2,y<2; j++,y++) {
   if (arr[i][j] <0)
    {
      arry[x][y]=arr[i][j];
      a=x;
      b=y;

           }
       }
   }
     for (int i = 0,int x=a;x<3, i < 3;x++, i++) {
   for (int j = 0,int y=b; j < 2,y<2; j++,y++) {
   if (arr[i][j] <0)
    {
      arry[x][y]=arr[i][j];


           }
       }
   }

 for (int i = 0; i < 2; i++) {
   for (int j = 0; j < 3; j++) {
           cout<< arry[i][j];
       }
   }





   return 0;
}

