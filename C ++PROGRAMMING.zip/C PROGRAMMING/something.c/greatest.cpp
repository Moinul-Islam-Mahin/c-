#include<iostream>
using namespace std;
int main(void)
{ int a,b,c;
cout<<"enter value of a"<<endl;
cin>>a;
cout<<"enter value of b"<<endl;
cin>>b;
cout<<"enter value of c"<<endl;
cin>>c;


if(a>b)
{if(a>c)
cout <<"c is the greatest"<<endl;
else
    cout<<"c is the greatest"<<endl;

}
else{
        if(b>c)
        cout <<"b is the greatest "<<endl;
else
    cout <<"c is the greatest"<<endl;



}

return 0;





}
