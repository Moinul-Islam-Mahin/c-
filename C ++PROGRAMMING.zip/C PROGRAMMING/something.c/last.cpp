#include<iostream>
using namespace std;
int main()
{
   int a,b,c;
   cout<<"enter your three numbers "<<endl;
   cin>>a>>b>>c;
   if(a<b && a<b)
   {

   cout<<"smallest "<<a<<endl;
   }

   else if(b<a && b<c)
    {cout<<"smallest"<<b<<endl;}
   else
    {cout<<" smallest"<<c;}





return 0; }
