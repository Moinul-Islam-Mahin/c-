#include<iostream>
using namespace std;



void arry(int age[2][2])
{
    for(int i=0;i<2;i++)
        {
        for(int j=0; j<2;j++)
            {
                cout<<age[i][j]<<endl;
            }
        }

}
int main()
{ int age[2][2]={12,14,15,14};


arry(age);


       return 0;
}
