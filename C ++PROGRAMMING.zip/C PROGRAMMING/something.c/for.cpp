// Function to count the number of characters in a string
#include <iostream>
using namespace std;
int stringLength (char string[])
{
int count = 0;
while ( string[count] != '\0' )
	++count;
return count;
}
int main (void) {
char word1[] = { 'a', 's', 't', 'e', 'r', '\0' };
char word2[] = { 'a', 't', '\0' };
char word3[] = { 'a', 'w', 'e', '\0' };
cout<<stringLength (word1)<<endl;
cout<<stringLength (word2)<<endl;
cout<<stringLength (word3)<<endl;
return 0;
}
