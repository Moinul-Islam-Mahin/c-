#include<iostream>
#include <string.h>
using namespace std;
struct Player{
string name;
double battingAvg;
double bowlingAvg;
int highestRun;
int playerType()
{ if(battingAvg >40)
{ cout<<" is Batter"<<endl;
return 1;}
else if(bowlingAvg <20)
{ cout<<" is Bowler"<<endl;
    return 2;
}
else if(battingAvg >30 && bowlingAvg <25)
{
    cout<<" is All rounder"<<endl;
    return 3;
}
else{cout<<" is Invalid Type of player"<<endl;}
}
void showInfo()
{
cout<<name<<endl<<battingAvg<<endl<<bowlingAvg<<endl<<highestRun<<endl;
}
};
int main()
{
    Player p1,p2,p3;
    p1.name= "aminul" ;
    p2.name= "miraz" ;
    p3.name= "stark" ;
    p1.battingAvg=48.22;
    p2.battingAvg=32.22;
    p3.battingAvg=12.34;
    p1.bowlingAvg=12;
    p2.bowlingAvg=28.33;
    p3.bowlingAvg=18.11;
    p1.highestRun=107;
    p2.highestRun=72;
    p3.highestRun=54;
    cout<<"players informations "<<endl;
    p1.showInfo();
    p2.showInfo();
    p3.showInfo();
      if(p1.highestRun>100)
      {
          cout<<p1.name<<" got century"<<endl;
      }
else if(p2.highestRun>100)
      {
          cout<<p2.name<<" got century"<<endl;
      }
else if(p3.highestRun>100)
      {
          cout<<p3.name<<" got century"<<endl;}
cout<<"aminul";
p1.playerType();cout<<endl;
cout<<"miraz";
p2.playerType();cout<<endl;
cout<<"stark";
p3.playerType();cout<<endl;
return 0;
}
