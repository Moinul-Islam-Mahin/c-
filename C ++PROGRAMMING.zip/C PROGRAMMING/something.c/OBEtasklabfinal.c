#include<iostream>
#include <string.h>
using namespace std;
struct Player{
string
double battingAvg
double bowlingAvg
int highestRun










};
